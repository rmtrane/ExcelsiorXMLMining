## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
library(ExcelsiorXMLMining)

data_folder <- "Data/"

## ------------------------------------------------------------------------
all_xml_data <- xml_to_tibble(folder = data_folder,
                              n_head = NA)

## ------------------------------------------------------------------------
str(all_xml_data, max.level = 1)

## ------------------------------------------------------------------------
all_xml_data

## ------------------------------------------------------------------------
validation_data <- xml_get_answers(all_xml_data)
str(validation_data, max.level = 1)

## ------------------------------------------------------------------------
str(head(all_xml_data$Results))

## ------------------------------------------------------------------------
str(head(validation_data$Results), max.level = 2)

## ------------------------------------------------------------------------
str(head(validation_data$Results[[1]]$QA), max.level = 2)

## ------------------------------------------------------------------------
write_rds(validation_data, "validation_data.rds")

## ------------------------------------------------------------------------
all_xml_data <- xml_to_tibble(folder = 'New_Data/',
                              n_head = 1)

## ------------------------------------------------------------------------
latest_valid_data <- read_rds(path = 'validation_data.rds')

## ------------------------------------------------------------------------
new_validation_data <- all_xml_data %>%
  anti_join(latest_valid_data %>% select(-Results)) %>% 
  xml_get_answers(show_progress = TRUE) 

## ------------------------------------------------------------------------
all_validation_data <- bind_rows(latest_valid_data, new_validation_data)

write_rds(all_validation_data,
          path = 'validation_data.rds')

