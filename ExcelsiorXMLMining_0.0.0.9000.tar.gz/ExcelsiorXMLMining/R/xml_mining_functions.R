#' Create tibble from xml files
#'
#' Takes a path to a folder and returns a tibble with all grading reports from all .xml files at
#' the specified folder. If n_head is NA (default), all gradingreports are included. If n_head is a positive number,
#' only n_head gradingreports from each .xml file in folder 'path' is included.
#'
#' @param folder specify folder form which all .xml files are used
#' @param file specify single file to load
#' @param n_head limit output to first n_head grading reports (passed to get_data_from_XML)
#'
#' @export

xml_to_tibble <- function(folder = NULL, file = NULL, n_head = NA){

  if(is.null(folder) + is.null(file) != 1){
    warning("Only one of 'folder' and 'file' should be provided")
  }

  if(is.null(file)){
    tib0 <- as.list(list.files(path = folder, pattern = ".xml", full.names = TRUE)) %>%
      map_df(~read_xml(.x) %>%
               get_data_from_XML(n_head = n_head)
      )
  } else {
    tib0 <- read_xml(x = file) %>% get_data_from_xml(n = n_head)
  }

  return(tib0)
}

#' Extract data from xml document
#'
#' From an xml document, get relevant characteristics and a list of results. Designed to work on the output of 'xml_to_tibble'.
#'
#' @param XML_document the xml_document part of a read_xml output from which data is to be extracted
#' @param n_head limit output to first n_head grading reports
#'
#' @export

get_data_from_XML <- function(XML_document, n_head = NA){

  ## First, find all XML documents.
  tib <- tibble(XML = xml_find_all(XML_document, "//GradingReport"))

  ## If n_head is specified, we only take the first n_head rows
  if(!is.na(n_head)){
    tib <- head(tib, n = n_head)
  }

  tib %>%
    mutate(Study               = XML %>% xml_child('Study') %>% xml_child('StudyName') %>% xml_text,
           Sponsors            = XML %>% xml_child('Sponsors') %>% xml_child('Sponsor') %>% xml_text,
           RandomizedSiteId    = XML %>% xml_child('Site') %>% xml_child('RandomizedSiteId') %>% xml_text,
           RandomizedSubjectId = XML %>% xml_child('Subject') %>% xml_child('RandomizedSubjectId') %>% xml_text,
           TimePoint           = XML %>% xml_child('TimePoint') %>% xml_text,
           StudyDate           = XML %>% xml_child('StudyDate') %>% xml_text,
           Procedure           = XML %>% xml_child('Procedure') %>% xml_text,
           Results             = XML %>% xml_child('Results'),
           PerformedBy         = Results %>% xml_attr(attr = 'PerformedBy'),
           PerformedDate       = Results %>% xml_attr(attr = 'PerformedDate')) %>%
    select(-XML)
}

#' Unfold answers from data
#'
#' The output from 'get_data_from_xml' includes a list column with xml_nodesets called 'Results'. This
#' column has all the information about questions and answers.
#' 'xml_get_answers' extracts the 'Question' and 'Answer' information from said column,
#' using the function 'get_answer_w_units'.
#'
#' @param tib0 result of get_data_from_xml
#' @param show_progress logical; if FALSE (default), progress bar is not shown
#'
#' @export

xml_get_answers <- function(tib0,
                            show_progress = FALSE){

  ## Print "Total number of reports".
  cat(paste("Total number of reports:", nrow(tib0), '\n'))


  ## If show_progress, initiate progress bar.
  if(show_progress)
    pb <- progress::progress_bar$new(total = nrow(tib0))


  ## This will be the output.
  tib <- tib0 %>%
    mutate(Results = map(Results,
                         function(x = .x){
                           ## We first create a tibble with all children in 'results'
                           tmp0 <- tibble(results = xml_children(x)) %>%
                             ## Get laterality, Question, and Question group from the 'results' entry
                             mutate(Laterality = xml_child(results, "Laterality") %>% xml_text,
                                    Question = xml_child(results, "Question") %>% xml_text,
                                    Q_Group = xml_child(results, "Group") %>% xml_text,
                                    ## Get answers and units using the 'get_answer_w_units' function
                                    Answers = map(results, get_answer_w_units)
                             ) %>%
                             select(-results) %>%
                             nest(-Laterality, .key = 'QA')

                           if(show_progress)
                             pb$tick()

                           return(tmp0)
                         }))
  return(tib)
}

#' Extract answers and corresponding units
#'
#' Gets answers and units from results part of xml grading reports
#'
#' @param results element from the 'results' list from the output of xml_get_answers
#'
#' @export

get_answer_w_units <- function(results){
  ## The fourth xml child of the xml nodeset
  tmp <- results %>% xml_child(4)

  ## If the name of this child is 'Answer', the question is categorical.
  ## For these questions we find the 'Measurement' as the text of the 'Question' child, the 'Name' (which in this case is for bookkeeping) is
  ## the same as the 'Measurement', and the 'Value' is the text of the tmp xml child.
  if(xml_name(tmp) == 'Answer'){
    tmp_tib <- tibble(Name = xml_child(results, 'Question') %>% xml_text,
                      Answer = list(tibble(Measurement = Name,
                                           Value = xml_text(tmp))),
                      Unit = '')
  } else {
    ## If the name of the child is NOT 'Answer', the question is numerical.
    ## We then proceed to get values for all subquestions, and units.
    tmp_tib <- tibble(children = tmp %>% xml_children) %>%
      mutate(children_children = map(children, xml_children),
             Name = map_chr(children, xml_name),
             value = map2(children_children, children,
                          function(x, y){
                            if(!length(xml_name(x))){
                              tibble(Measurement = xml_name(y), Value = xml_text(y))
                            } else {
                              tibble(Measurement = xml_name(x), Value = xml_text(x))
                            }
                          }),
             type = case_when(str_detect(Name, 'Unit') ~ 'Unit',
                              TRUE ~ 'Answer'),
             Name = str_replace(Name, 'Unit|Length', '')) %>%
      select(Name:type) %>%
      spread(type, value) %>%
      mutate(Unit = map_chr(Unit, ~ifelse(is.null(.x), '', pull(.x, Value))))
  }

  return(tmp_tib)
}
